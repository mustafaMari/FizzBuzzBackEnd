create function time(abstime) returns time without time zone
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select cast(cast($1 as timestamp without time zone) as pg_catalog.time)
$$;

comment on function time(abstime) is 'convert abstime to time';

alter function time(abstime) owner to postgres;

